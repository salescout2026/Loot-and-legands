# QuestForge5E: Loot & Legends

A solo 5E-inspired fantasy adventure app built around **The Shattered Coast**.

## Included content

- Character creation
- Handcrafted quest board
- Completed quests disappear permanently
- Branching story flags and consequences
- Visual scrollable map with active route progress
- D20 checks and simple combat
- Inventory, gold, reputation, HP, XP, and local save/load
- Shipyard screen with visual upgrades
- Major story quest: **The Bell Beneath the Sea**

## Quests

1. Rats in the Cellar
2. The Lantern on Widow's Rock
3. The Blackroot Cure
4. The Missing Cart
5. The Bell Beneath the Sea

## Build Android APK on GitHub

The GitHub Actions file must be located at:

.github/workflows/android-debug-apk.yml

After uploading the files, open the Actions tab and run **Build Android Debug APK**.
